
export const COLORS = {
  AMBER: '#FFB300',
  DARK: '#1a1a1a',
  GOLD_GLOW: 'rgba(255, 179, 0, 0.6)',
};

export const HEX_WIDTH = 210;
export const HEX_HEIGHT = 240;
